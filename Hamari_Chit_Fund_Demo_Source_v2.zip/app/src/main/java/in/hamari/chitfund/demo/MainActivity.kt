package in.hamari.chitfund.demo

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class DemoMember(val name: String, val phone: String)
data class DemoLoan(val id: Int, val member: String, val principal: Int, val rate: Int, val date: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("demo", MODE_PRIVATE)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF44336A))) {
                var unlocked by remember { mutableStateOf(false) }
                var pin by remember { mutableStateOf("") }
                var page by remember { mutableStateOf("Dashboard") }
                var members by remember { mutableStateOf(listOf(
                    DemoMember("प्रवीण", "0000000001"),
                    DemoMember("सुनीता", "0000000002"),
                    DemoMember("रमेश", "0000000003")
                )) }
                var loans by remember { mutableStateOf(listOf(
                    DemoLoan(1001, "प्रवीण", 4000, 2, "10/11/2026"),
                    DemoLoan(1002, "सुनीता", 2500, 2, "08/11/2026")
                )) }
                var nextId by remember { mutableIntStateOf(1003) }
                var cash by remember { mutableIntStateOf(12500) }
                var paid by remember { mutableIntStateOf(1500) }

                if (!unlocked) {
                    PinScreen(pin, { pin = it }, {
                        if (pin.length == 4) {
                            if (prefs.getString("pin", null) == null) prefs.edit().putString("pin", pin).apply()
                            if (prefs.getString("pin", null) == pin) unlocked = true
                        }
                    }, prefs.getString("pin", null) == null)
                } else {
                    Scaffold(
                        bottomBar = {
                            NavigationBar {
                                listOf("Dashboard", "सदस्य", "लोन", "जमा").forEach { item ->
                                    NavigationBarItem(
                                        selected = page == item, onClick = { page = item },
                                        icon = { Text(when(item) { "Dashboard" -> "⌂"; "सदस्य" -> "♙"; "लोन" -> "₹"; else -> "+" }, fontSize = 20.sp) },
                                        label = { Text(item) }
                                    )
                                }
                            }
                        }
                    ) { padding ->
                        Column(Modifier.fillMaxSize().padding(padding).padding(18.dp)) {
                            Text("हमारी चिट फण्ड फैमिली 2.0", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                            Text("DEMO MODE · केवल नमूना डेटा", color = MaterialTheme.colorScheme.primary, fontSize = 12.sp)
                            Spacer(Modifier.height(18.dp))
                            when(page) {
                                "Dashboard" -> {
                                    MetricCard("कुल Demo Cash", "₹${cash}")
                                    MetricCard("कुल बकाया लोन", "₹${loans.sumOf { it.principal }}")
                                    MetricCard("जमा एंट्री (Demo)", "₹${paid}")
                                    Spacer(Modifier.height(12.dp))
                                    Text("हाल के लोन", fontWeight = FontWeight.Bold)
                                    loans.forEach { Text("Loan #${it.id} · ${it.member} · ₹${it.principal} · ${it.rate}%/माह", Modifier.padding(vertical=6.dp)) }
                                }
                                "सदस्य" -> {
                                    Text("Demo Members", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                    members.forEach { ListItem(headlineContent = { Text(it.name) }, supportingContent = { Text(it.phone) }) }
                                    Text("असली सदस्य बाद में आयात होंगे।", color = MaterialTheme.colorScheme.secondary)
                                }
                                "लोन" -> LoanForm(members.map { it.name }, nextId) { name, amount, rate ->
                                    if (amount > 0) {
                                        loans = loans + DemoLoan(nextId, name, amount, rate, "आज")
                                        nextId++
                                    }
                                }
                                else -> JamaForm { amount ->
                                    if (amount > 0) { paid += amount; cash += amount }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable fun PinScreen(pin: String, onPin: (String)->Unit, onUnlock: ()->Unit, first: Boolean) {
    Column(Modifier.fillMaxSize().padding(28.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Text("हमारी चिट फण्ड फैमिली 2.0", fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(if(first) "Demo के लिए नया 4 अंकों का PIN बनाओ" else "अपना 4 अंकों का PIN डालो")
        Spacer(Modifier.height(20.dp))
        OutlinedTextField(pin, { if(it.length <= 4 && it.all(Char::isDigit)) onPin(it) }, label={Text("4-digit PIN")}, keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.NumberPassword), singleLine=true)
        Spacer(Modifier.height(16.dp))
        Button(onClick=onUnlock, enabled=pin.length == 4) { Text("आगे बढ़ें") }
        Text("Demo PIN इसी फोन में सेव होगा।", fontSize=12.sp, color=MaterialTheme.colorScheme.secondary)
    }
}

@Composable fun MetricCard(title: String, value: String) {
    Card(Modifier.fillMaxWidth().padding(bottom=10.dp), shape=RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(18.dp)) {
            Text(title, color=MaterialTheme.colorScheme.secondary)
            Text(value, fontSize=25.sp, fontWeight=FontWeight.Bold)
        }
    }
}

@Composable fun LoanForm(names: List<String>, id: Int, onSave: (String,Int,Int)->Unit) {
    var member by remember { mutableStateOf(names.firstOrNull() ?: "") }
    var amount by remember { mutableStateOf("") }
    var rate by remember { mutableIntStateOf(2) }
    Text("नया Demo Loan", fontSize=19.sp, fontWeight=FontWeight.Bold)
    Text("अगला Loan ID: $id", color=MaterialTheme.colorScheme.primary)
    Spacer(Modifier.height(12.dp))
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(expanded=expanded, onExpandedChange={expanded=it}) {
        OutlinedTextField(member, { }, readOnly=true, label={Text("सदस्य")}, modifier=Modifier.menuAnchor().fillMaxWidth())
        ExposedDropdownMenu(expanded=expanded, onDismissRequest={expanded=false}) {
            names.forEach { DropdownMenuItem(text={Text(it)}, onClick={member=it; expanded=false}) }
        }
    }
    OutlinedTextField(amount, { amount=it.filter(Char::isDigit) }, label={Text("मूलधन (₹)")}, keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number), modifier=Modifier.fillMaxWidth())
    Row(verticalAlignment=Alignment.CenterVertically) {
        Text("ब्याज दर: ")
        FilterChip(selected=rate==2, onClick={rate=2}, label={Text("2% सदस्य")})
        Spacer(Modifier.width(8.dp))
        FilterChip(selected=rate==5, onClick={rate=5}, label={Text("5% गैर-सदस्य")})
    }
    Button(onClick={onSave(member, amount.toIntOrNull() ?: 0, rate)}, modifier=Modifier.fillMaxWidth(), enabled=(amount.toIntOrNull() ?: 0)>0) { Text("Demo Loan सेव करें") }
    Text("नोट: यह केवल demo गणना/एंट्री है; वास्तविक ब्याज नियम अभी जोड़ा नहीं गया।", fontSize=12.sp)
}

@Composable fun JamaForm(onSave: (Int)->Unit) {
    var amount by remember { mutableStateOf("") }
    Text("जमा एंट्री (Demo)", fontSize=19.sp, fontWeight=FontWeight.Bold)
    OutlinedTextField(amount, { amount=it.filter(Char::isDigit) }, label={Text("जमा राशि (₹)")}, keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number), modifier=Modifier.fillMaxWidth())
    Spacer(Modifier.height(12.dp))
    Button(onClick={onSave(amount.toIntOrNull() ?: 0); amount=""}, enabled=(amount.toIntOrNull() ?: 0)>0, modifier=Modifier.fillMaxWidth()) { Text("जमा सेव करें") }
    Text("इस शुरुआती demo में जमा कुल राशि में जुड़ती है; Loan-wise हिसाब अगले चरण में बनेगा।", fontSize=12.sp)
}
